# CloudPose: Cloud-based Pose Detection Service

## Project Submission Information

### Video Demo URL
https://drive.google.com/drive/folders/1uQ4NWZdLD-6TVORJ_OszoYQu1r038KMH

### Service Endpoint URL
http://47.99.104.47:30000/api/pose_detection

### Student Information
- **Student Name**: [JunjieZhou]
- **Student ID**: [35524316]
- **Supervisor**: [BenDuan]
- **Model Used**: MoveNet-Full-256

### Technology Stack
- **Cloud Provider**: Alibaba Cloud (Hangzhou Region)
- **Container Technology**: Docker 20.10+
- **Orchestration Platform**: Kubernetes 1.28.2
- **Network Plugin**: Flannel
- **Load Testing**: Locust
- **Development Language**: Python 3.9

## Quick Deployment Guide

### 1. Environment Setup
```bash
# Set script execution permissions
chmod +x *.sh

# Run environment configuration on all nodes
./setup_aliyun_environment.sh all

# Re-login to apply Docker group permissions
logout
# SSH back in
```

### 2. Cluster Initialization

**Master Node:**
```bash
./setup_aliyun_environment.sh master
```

### 3. Application Deployment
```bash
# Verify model file exists
ls -la movenet-full-256.tflite

# Execute complete deployment
./deploy_cloudpose.sh deploy

# Verify deployment status
./deploy_cloudpose.sh verify
```

### 4. Load Testing
```bash
# Install testing dependencies
pip3 install locust matplotlib pandas

# Create test image directory (optional)
mkdir images
# Place test image files in the images directory

# Run automated experiments
python3 experiment_runner.py --host http://47.99.104.47:30000 --pods 1,2,4
```

## File Structure

```
cloudpose/
├── app.py                      # FastAPI main application
├── requirements.txt            # Python dependencies
├── Dockerfile                  # Docker build file
├── deployment.yaml             # Kubernetes deployment configuration
├── locust_client.py           # Load testing script
├── experiment_runner.py       # Experiment automation
├── setup_aliyun_environment.sh # Environment setup script
├── deploy_cloudpose.sh        # Deployment script
├── monitor_cloudpose.sh       # Monitoring script
├── movenet-full-256.tflite    # MoveNet model file
└── README.md                  # This file
```