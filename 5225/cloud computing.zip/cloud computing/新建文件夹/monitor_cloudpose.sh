#!/bin/bash
# monitor_cloudpose.sh
# CloudPose监控和管理脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# 配置变量
APP_NAME="cloudpose"
DEPLOYMENT_NAME="cloudpose-deployment"
SERVICE_NAME="cloudpose-service"
NAMESPACE="default"

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 显示系统状态
show_system_status() {
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║                        CLOUDPOSE SYSTEM STATUS                   ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    
    # 集群信息
    echo -e "\n${PURPLE}📊 Cluster Information:${NC}"
    kubectl cluster-info --request-timeout=10s 2>/dev/null || log_error "Cannot connect to cluster"
    
    # 节点状态
    echo -e "\n${PURPLE}🖥️  Node Status:${NC}"
    kubectl get nodes -o wide
    
    # 部署状态
    echo -e "\n${PURPLE}🚀 Deployment Status:${NC}"
    kubectl get deployment $DEPLOYMENT_NAME -o wide 2>/dev/null || log_warn "Deployment not found"
    
    # Pod状态
    echo -e "\n${PURPLE}🐳 Pod Status:${NC}"
    kubectl get pods -l app=$APP_NAME -o wide 2>/dev/null || log_warn "No pods found"
    
    # 服务状态
    echo -e "\n${PURPLE}🌐 Service Status:${NC}"
    kubectl get service $SERVICE_NAME -o wide 2>/dev/null || log_warn "Service not found"
    
    # 资源使用情况
    echo -e "\n${PURPLE}📈 Resource Usage:${NC}"
    if command -v kubectl-top >/dev/null 2>&1 || kubectl top nodes >/dev/null 2>&1; then
        echo "Node Resource Usage:"
        kubectl top nodes 2>/dev/null || log_warn "Metrics server not available"
        
        echo -e "\nPod Resource Usage:"
        kubectl top pods -l app=$APP_NAME 2>/dev/null || log_warn "Pod metrics not available"
    else
        log_warn "Metrics server not installed"
    fi
}

# 显示详细的Pod信息
show_pod_details() {
    log_step "Showing detailed pod information..."
    
    local pods=$(kubectl get pods -l app=$APP_NAME -o jsonpath='{.items[*].metadata.name}' 2>/dev/null)
    
    if [[ -z "$pods" ]]; then
        log_error "No pods found"
        return 1
    fi
    
    for pod in $pods; do
        echo -e "\n${CYAN}═══ Pod: $pod ═══${NC}"
        
        # Pod基本信息
        kubectl get pod $pod -o wide
        
        # Pod描述（如果需要详细信息）
        echo -e "\n${PURPLE}Pod Details:${NC}"
        kubectl describe pod $pod | head -20
        
        # 检查健康状态
        echo -e "\n${PURPLE}Health Check:${NC}"
        local health_status=$(kubectl exec $pod -- curl -s -o /dev/null -w "%{http_code}" http://localhost:60000/health 2>/dev/null || echo "FAILED")
        if [[ "$health_status" == "200" ]]; then
            log_info "✅ Health check: PASSED"
        else
            log_error "❌ Health check: FAILED (Status: $health_status)"
        fi
        
        # 最近日志
        echo -e "\n${PURPLE}Recent Logs (last 10 lines):${NC}"
        kubectl logs $pod --tail=10 2>/dev/null || log_warn "Cannot retrieve logs"
    done
}

# 监控服务端点
monitor_endpoints() {
    log_step "Monitoring service endpoints..."
    
    local service_ip=$(kubectl get service $SERVICE_NAME -o jsonpath='{.spec.clusterIP}' 2>/dev/null)
    local node_port=$(kubectl get service $SERVICE_NAME -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null)
    local external_ip=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' 2>/dev/null)
    
    echo -e "\n${PURPLE}🔗 Service Endpoints:${NC}"
    
    if [[ -n "$service_ip" ]]; then
        echo "Internal URL: http://$service_ip:60000"
        
        # 测试内部端点
        local internal_status=$(kubectl run test-pod --image=curlimages/curl --rm -i --restart=Never -- curl -s -o /dev/null -w "%{http_code}" http://$service_ip:60000/health 2>/dev/null || echo "FAILED")
        if [[ "$internal_status" == "200" ]]; then
            log_info "✅ Internal endpoint: ACCESSIBLE"
        else
            log_error "❌ Internal endpoint: NOT ACCESSIBLE"
        fi
    fi
    
    if [[ -n "$node_port" ]]; then
        echo "NodePort: $node_port"
        
        if [[ -n "$external_ip" ]]; then
            echo "External URL: http://$external_ip:$node_port"
            
            # 测试外部端点
            local external_status=$(curl -s -o /dev/null -w "%{http_code}" http://$external_ip:$node_port/health 2>/dev/null || echo "FAILED")
            if [[ "$external_status" == "200" ]]; then
                log_info "✅ External endpoint: ACCESSIBLE"
            else
                log_error "❌ External endpoint: NOT ACCESSIBLE"
            fi
        else
            log_warn "No external IP found"
        fi
    fi
}

# 性能测试
performance_test() {
    local duration=${1:-30}
    local users=${2:-5}
    
    log_step "Running performance test (${duration}s, ${users} users)..."
    
    # 检查是否安装了locust
    if ! command -v locust >/dev/null 2>&1; then
        log_error "Locust not installed. Install with: pip install locust"
        return 1
    fi
    
    # 检查locust_client.py是否存在
    if [[ ! -f "locust_client.py" ]]; then
        log_error "locust_client.py not found"
        return 1
    fi
    
    # 获取服务URL
    local external_ip=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' 2>/dev/null)
    local node_port=$(kubectl get service $SERVICE_NAME -o jsonpath='{.spec.ports[0].nodePort}' 2>/dev/null)
    
    if [[ -z "$external_ip" || -z "$node_port" ]]; then
        log_error "Cannot determine service URL"
        return 1
    fi
    
    local service_url="http://$external_ip:$node_port"
    
    log_info "Testing URL: $service_url"
    log_info "Test duration: ${duration}s"
    log_info "Concurrent users: $users"
    
    # 运行locust测试
    locust -f locust_client.py --host=$service_url --users=$users --spawn-rate=1 --run-time=${duration}s --headless --csv=perf_test
    
    # 显示结果摘要
    if [[ -f "perf_test_stats.csv" ]]; then
        echo -e "\n${PURPLE}📊 Performance Test Results:${NC}"
        cat perf_test_stats.csv | column -t -s','
    fi
}

# 查看实时日志
tail_logs() {
    log_step "Tailing application logs (Ctrl+C to stop)..."
    
    kubectl logs -l app=$APP_NAME -f --tail=50
}

# 执行命令在所有Pod中
exec_in_pods() {
    local command="$1"
    
    if [[ -z "$command" ]]; then
        log_error "Please provide a command to execute"
        return 1
    fi
    
    log_step "Executing command in all pods: $command"
    
    local pods=$(kubectl get pods -l app=$APP_NAME -o jsonpath='{.items[*].metadata.name}' 2>/dev/null)
    
    for pod in $pods; do
        echo -e "\n${CYAN}═══ Pod: $pod ═══${NC}"
        kubectl exec $pod -- $command 2>/dev/null || log_warn "Command failed in pod $pod"
    done
}

# 收集诊断信息
collect_diagnostics() {
    local output_dir="diagnostics_$(date +%Y%m%d_%H%M%S)"
    
    log_step "Collecting diagnostic information..."
    
    mkdir -p $output_dir
    
    # 基本信息
    kubectl cluster-info > $output_dir/cluster_info.txt 2>&1
    kubectl get nodes -o wide > $output_dir/nodes.txt 2>&1
    kubectl get all -o wide > $output_dir/resources.txt 2>&1
    
    # 部署信息
    kubectl describe deployment $DEPLOYMENT_NAME > $output_dir/deployment.txt 2>&1
    kubectl describe service $SERVICE_NAME > $output_dir/service.txt 2>&1
    
    # Pod信息
    kubectl get pods -l app=$APP_NAME -o yaml > $output_dir/pods.yaml 2>&1
    kubectl describe pods -l app=$APP_NAME > $output_dir/pod_details.txt 2>&1
    
    # 日志
    kubectl logs -l app=$APP_NAME --all-containers=true > $output_dir/application_logs.txt 2>&1
    
    # 事件
    kubectl get events --sort-by=.metadata.creationTimestamp > $output_dir/events.txt 2>&1
    
    # 如果metrics server可用，收集资源使用情况
    kubectl top nodes > $output_dir/node_metrics.txt 2>&1 || true
    kubectl top pods -l app=$APP_NAME > $output_dir/pod_metrics.txt 2>&1 || true
    
    log_info "Diagnostic information collected in: $output_dir"
    
    # 创建压缩包
    tar -czf ${output_dir}.tar.gz $output_dir
    log_info "Compressed diagnostics: ${output_dir}.tar.gz"
    
    # 清理目录
    rm -rf $output_dir
}

# 显示使用说明
show_usage() {
    echo -e "${CYAN}CloudPose Monitoring and Management Script${NC}"
    echo ""
    echo "Usage: $0 [COMMAND] [OPTIONS]"
    echo ""
    echo -e "${PURPLE}Monitoring Commands:${NC}"
    echo "  status       - Show complete system status (default)"
    echo "  pods         - Show detailed pod information"
    echo "  endpoints    - Monitor service endpoints"
    echo "  logs         - Tail application logs"
    echo "  metrics      - Show resource metrics"
    echo ""
    echo -e "${PURPLE}Testing Commands:${NC}"
    echo "  test [DURATION] [USERS]  - Run performance test (default: 30s, 5 users)"
    echo "  health       - Check application health"
    echo ""
    echo -e "${PURPLE}Management Commands:${NC}"
    echo "  exec COMMAND - Execute command in all pods"
    echo "  diagnose     - Collect diagnostic information"
    echo "  watch        - Watch pod status (refreshes every 2s)"
    echo ""
    echo -e "${PURPLE}Examples:${NC}"
    echo "  $0 status                    # Show system status"
    echo "  $0 test 60 10               # Test with 10 users for 60 seconds"
    echo "  $0 exec 'ps aux'           # Show processes in all pods"
    echo "  $0 diagnose                 # Collect diagnostics"
}

# 监控循环
watch_status() {
    log_step "Watching pod status (Ctrl+C to stop)..."
    
    while true; do
        clear
        show_system_status
        echo -e "\n${CYAN}Last updated: $(date)${NC}"
        sleep 2
    done
}

# 主函数
main() {
    local command=${1:-status}
    
    case $command in
        "status")
            show_system_status
            ;;
        "pods")
            show_pod_details
            ;;
        "endpoints")
            monitor_endpoints
            ;;
        "logs")
            tail_logs
            ;;
        "metrics")
            kubectl top nodes 2>/dev/null || log_warn "Metrics server not available"
            kubectl top pods -l app=$APP_NAME 2>/dev/null || log_warn "Pod metrics not available"
            ;;
        "test")
            performance_test ${2:-30} ${3:-5}
            ;;
        "health")
            local pods=$(kubectl get pods -l app=$APP_NAME -o jsonpath='{.items[*].metadata.name}' 2>/dev/null)
            for pod in $pods; do
                echo "Testing pod: $pod"
                kubectl exec $pod -- curl -s http://localhost:60000/health || log_error "Health check failed for $pod"
            done
            ;;
        "exec")
            if [[ -z "$2" ]]; then
                log_error "Please provide a command to execute"
                exit 1
            fi
            shift
            exec_in_pods "$*"
            ;;
        "diagnose")
            collect_diagnostics
            ;;
        "watch")
            watch_status
            ;;
        "help"|"-h"|"--help")
            show_usage
            ;;
        *)
            log_error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"