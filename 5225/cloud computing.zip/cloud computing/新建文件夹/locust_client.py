# locust_client.py
from locust import HttpUser, task, between, events
import base64
import uuid
import json
import os
import glob
import random
import time
import logging
from io import BytesIO
from PIL import Image
import numpy as np

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CloudPoseUser(HttpUser):
    wait_time = between(1, 3)  # 请求间隔时间
    
    def on_start(self):
        """在测试开始时初始化"""
        self.images = self.load_images()
        if not self.images:
            logger.error("No test images loaded!")
            self.environment.runner.quit()
    
    def load_images(self):
        """加载测试图像"""
        images = []
        
        # 尝试从多个可能的目录加载图像
        possible_dirs = ["images", "test_images", "../images", "./"]
        image_extensions = ["*.jpg", "*.jpeg", "*.png", "*.bmp"]
        
        for directory in possible_dirs:
            if os.path.exists(directory):
                for ext in image_extensions:
                    pattern = os.path.join(directory, ext)
                    image_files = glob.glob(pattern)
                    
                    for image_file in image_files:
                        try:
                            # 验证图像可以正常加载
                            with Image.open(image_file) as img:
                                # 转换为RGB模式（如果需要）
                                if img.mode != 'RGB':
                                    img = img.convert('RGB')
                                
                                # 调整图像大小以减少传输时间（可选）
                                max_size = 800
                                if max(img.size) > max_size:
                                    img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                                
                                # 保存为JPEG格式的base64
                                buffer = BytesIO()
                                img.save(buffer, format='JPEG', quality=85)
                                image_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
                                
                                images.append({
                                    'data': image_data,
                                    'filename': os.path.basename(image_file),
                                    'size': len(image_data)
                                })
                                
                                logger.info(f"Loaded image: {image_file}")
                                
                        except Exception as e:
                            logger.warning(f"Failed to load image {image_file}: {e}")
                
                if images:  # 如果在当前目录找到了图像，就不再搜索其他目录
                    break
        
        if not images:
            # 如果没有找到图像文件，创建一个测试图像
            logger.warning("No image files found, creating a synthetic test image")
            images = [self.create_test_image()]
        
        logger.info(f"Loaded {len(images)} test images")
        return images
    
    def create_test_image(self):
        """创建一个合成测试图像"""
        try:
            # 创建一个简单的测试图像
            img = Image.new('RGB', (640, 480), color='white')
            
            # 可以添加一些图形来模拟人体姿态
            import PIL.ImageDraw as ImageDraw
            draw = ImageDraw.Draw(img)
            
            # 绘制一个简单的人形轮廓
            # 头部
            draw.ellipse([300, 50, 340, 90], fill='blue')
            # 身体
            draw.rectangle([310, 90, 330, 200], fill='blue')
            # 手臂
            draw.rectangle([280, 100, 310, 120], fill='blue')  # 左臂
            draw.rectangle([330, 100, 360, 120], fill='blue')  # 右臂
            # 腿部
            draw.rectangle([305, 200, 320, 300], fill='blue')  # 左腿
            draw.rectangle([320, 200, 335, 300], fill='blue')  # 右腿
            
            # 转换为base64
            buffer = BytesIO()
            img.save(buffer, format='JPEG', quality=85)
            image_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
            
            return {
                'data': image_data,
                'filename': 'synthetic_test.jpg',
                'size': len(image_data)
            }
            
        except Exception as e:
            logger.error(f"Failed to create test image: {e}")
            return None
    
    @task(3)
    def pose_detection_json(self):
        """测试JSON API端点"""
        if not self.images:
            return
        
        image = random.choice(self.images)
        img_id = str(uuid.uuid4())
        
        payload = {
            "id": img_id,
            "image": image['data']
        }
        
        headers = {'Content-Type': 'application/json'}
        
        start_time = time.time()
        
        with self.client.post(
            "/api/pose_detection",
            json=payload,
            headers=headers,
            catch_response=True,
            name="pose_detection_json"
        ) as response:
            response_time = (time.time() - start_time) * 1000  # 转换为毫秒
            
            if response.status_code == 200:
                try:
                    result = response.json()
                    
                    # 验证响应格式
                    required_fields = ["id", "count", "boxes", "keypoints", 
                                     "speed_preprocess", "speed_inference", "speed_postprocess"]
                    
                    if all(field in result for field in required_fields):
                        if result["id"] == img_id:
                            response.success()
                            logger.debug(f"Successful JSON API call for {image['filename']}: "
                                       f"{response_time:.2f}ms, detected {result['count']} persons")
                        else:
                            response.failure(f"ID mismatch: expected {img_id}, got {result.get('id')}")
                    else:
                        missing = [f for f in required_fields if f not in result]
                        response.failure(f"Missing fields in response: {missing}")
                        
                except json.JSONDecodeError as e:
                    response.failure(f"Invalid JSON response: {e}")
                except Exception as e:
                    response.failure(f"Response validation error: {e}")
            else:
                response.failure(f"HTTP {response.status_code}: {response.text}")
    
    @task(1)
    def pose_detection_image(self):
        """测试图像注释API端点"""
        if not self.images:
            return
        
        image = random.choice(self.images)
        img_id = str(uuid.uuid4())
        
        payload = {
            "id": img_id,
            "image": image['data']
        }
        
        headers = {'Content-Type': 'application/json'}
        
        start_time = time.time()
        
        with self.client.post(
            "/api/pose_detection_annotation",
            json=payload,
            headers=headers,
            catch_response=True,
            name="pose_detection_image"
        ) as response:
            response_time = (time.time() - start_time) * 1000
            
            if response.status_code == 200:
                try:
                    result = response.json()
                    
                    if "id" in result and "image" in result:
                        if result["id"] == img_id and result["image"]:
                            # 验证返回的图像是有效的base64
                            try:
                                base64.b64decode(result["image"])
                                response.success()
                                logger.debug(f"Successful Image API call for {image['filename']}: "
                                           f"{response_time:.2f}ms")
                            except Exception:
                                response.failure("Invalid base64 image in response")
                        else:
                            response.failure("Invalid response format or ID mismatch")
                    else:
                        response.failure("Missing required fields in response")
                        
                except json.JSONDecodeError as e:
                    response.failure(f"Invalid JSON response: {e}")
                except Exception as e:
                    response.failure(f"Response validation error: {e}")
            else:
                response.failure(f"HTTP {response.status_code}: {response.text}")
    
    @task(1)
    def health_check(self):
        """健康检查端点测试"""
        with self.client.get("/health", catch_response=True, name="health_check") as response:
            if response.status_code == 200:
                try:
                    result = response.json()
                    if result.get("status") == "healthy":
                        response.success()
                    else:
                        response.failure(f"Unhealthy status: {result}")
                except:
                    response.failure("Invalid health check response")
            else:
                response.failure(f"Health check failed: HTTP {response.status_code}")

# 事件监听器用于收集详细统计信息
@events.request.add_listener
def request_handler(request_type, name, response_time, response_length, exception, context, **kwargs):
    """记录请求详细信息"""
    if exception:
        logger.error(f"Request failed: {name} - {exception}")
    else:
        logger.debug(f"Request: {name}, Response time: {response_time}ms, Length: {response_length}")

@events.test_start.add_listener
def test_start_handler(environment, **kwargs):
    """测试开始时的处理"""
    logger.info("CloudPose Load Test Started")
    logger.info(f"Target host: {environment.host}")

@events.test_stop.add_listener
def test_stop_handler(environment, **kwargs):
    """测试结束时的处理"""
    logger.info("CloudPose Load Test Completed")
    
    # 打印统计摘要
    stats = environment.stats
    logger.info(f"Total requests: {stats.total.num_requests}")
    logger.info(f"Total failures: {stats.total.num_failures}")
    logger.info(f"Average response time: {stats.total.avg_response_time:.2f}ms")
    logger.info(f"Success rate: {((stats.total.num_requests - stats.total.num_failures) / stats.total.num_requests * 100):.2f}%")

