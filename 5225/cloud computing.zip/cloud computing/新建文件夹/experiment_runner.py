#!/usr/bin/env python3
"""
CloudPose实验自动化脚本
用于自动化运行不同Pod数量下的负载测试
"""

import subprocess
import time
import json
import csv
import os
import sys
import logging
import argparse
from typing import List, Dict, Optional
import matplotlib.pyplot as plt
import pandas as pd
from datetime import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('experiment.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ExperimentRunner:
    def __init__(self, host_url: str, deployment_name: str = "cloudpose-deployment"):
        self.host_url = host_url
        self.deployment_name = deployment_name
        self.results = []
        self.experiment_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def run_command(self, command: str, timeout: int = 300) -> tuple:
        """执行shell命令并返回结果"""
        try:
            logger.info(f"Executing: {command}")
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=timeout
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            logger.error(f"Command timed out: {command}")
            return -1, "", "Command timed out"
        except Exception as e:
            logger.error(f"Command failed: {e}")
            return -1, "", str(e)
    
    def check_kubectl(self) -> bool:
        """检查kubectl是否可用"""
        returncode, stdout, stderr = self.run_command("kubectl version --client")
        if returncode != 0:
            logger.error("kubectl not found or not configured")
            return False
        return True
    
    def check_deployment_exists(self) -> bool:
        """检查部署是否存在"""
        returncode, stdout, stderr = self.run_command(f"kubectl get deployment {self.deployment_name}")
        if returncode != 0:
            logger.error(f"Deployment {self.deployment_name} not found")
            return False
        return True
    
    def scale_deployment(self, replicas: int) -> bool:
        """扩展部署的Pod数量"""
        logger.info(f"Scaling deployment to {replicas} replicas...")
        
        # 扩展部署
        returncode, stdout, stderr = self.run_command(
            f"kubectl scale deployment {self.deployment_name} --replicas={replicas}"
        )
        
        if returncode != 0:
            logger.error(f"Failed to scale deployment: {stderr}")
            return False
        
        # 等待Pod就绪
        logger.info("Waiting for pods to be ready...")
        max_wait_time = 300  # 5分钟超时
        start_time = time.time()
        
        while time.time() - start_time < max_wait_time:
            returncode, stdout, stderr = self.run_command(
                f"kubectl get deployment {self.deployment_name} -o jsonpath='{{.status.readyReplicas}}'"
            )
            
            if returncode == 0 and stdout.strip():
                ready_replicas = int(stdout.strip())
                if ready_replicas == replicas:
                    logger.info(f"All {replicas} pods are ready")
                    time.sleep(10)  # 额外等待时间确保稳定
                    return True
            
            logger.info(f"Waiting for pods to be ready... ({int(time.time() - start_time)}s)")
            time.sleep(10)
        
        logger.error("Timeout waiting for pods to be ready")
        return False
    
    def get_pod_status(self) -> Dict:
        """获取Pod状态信息"""
        returncode, stdout, stderr = self.run_command(
            f"kubectl get pods -l app=cloudpose -o json"
        )
        
        if returncode != 0:
            logger.error(f"Failed to get pod status: {stderr}")
            return {}
        
        try:
            pods_data = json.loads(stdout)
            pods_info = []
            
            for pod in pods_data.get('items', []):
                pod_info = {
                    'name': pod['metadata']['name'],
                    'status': pod['status']['phase'],
                    'ready': all(condition['status'] == 'True' 
                               for condition in pod.get('status', {}).get('conditions', [])
                               if condition['type'] == 'Ready')
                }
                pods_info.append(pod_info)
            
            return {
                'total_pods': len(pods_info),
                'ready_pods': sum(1 for pod in pods_info if pod['ready']),
                'pods': pods_info
            }
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse pod status JSON: {e}")
            return {}
    
    def run_locust_test(self, users: int, spawn_rate: int = 1, duration: int = 300) -> Optional[Dict]:
        """运行Locust负载测试"""
        logger.info(f"Running Locust test: {users} users, spawn rate {spawn_rate}, duration {duration}s")
        
        # 创建结果目录
        results_dir = f"results_{self.experiment_id}"
        os.makedirs(results_dir, exist_ok=True)
        
        # 生成唯一的结果文件名
        result_prefix = f"{results_dir}/test_{users}users_{int(time.time())}"
        
        # 构建Locust命令
        cmd = [
            "locust",
            "-f", "locust_client.py",
            "--host", self.host_url,
            "--users", str(users),
            "--spawn-rate", str(spawn_rate),
            "--run-time", f"{duration}s",
            "--headless",
            "--csv", result_prefix,
            "--html", f"{result_prefix}.html"
        ]
        
        logger.info(f"Running command: {' '.join(cmd)}")
        
        try:
            # 运行Locust测试
            process = subprocess.run(cmd, capture_output=True, text=True, timeout=duration + 60)
            
            if process.returncode != 0:
                logger.error(f"Locust test failed: {process.stderr}")
                return None
            
            # 解析结果
            stats_file = f"{result_prefix}_stats.csv"
            if os.path.exists(stats_file):
                return self.parse_locust_results(stats_file)
            else:
                logger.error(f"Results file not found: {stats_file}")
                return None
                
        except subprocess.TimeoutExpired:
            logger.error("Locust test timed out")
            return None
        except Exception as e:
            logger.error(f"Error running Locust test: {e}")
            return None
    
    def parse_locust_results(self, csv_file: str) -> Dict:
        """解析Locust CSV结果"""
        try:
            df = pd.read_csv(csv_file)
            
            # 过滤掉Aggregated行，只计算具体的API端点
            api_stats = df[df['Name'] != 'Aggregated']
            
            if len(api_stats) == 0:
                logger.warning("No API stats found in results")
                return {
                    'total_requests': 0,
                    'total_failures': 0,
                    'success_rate': 0,
                    'avg_response_time': 0,
                    'max_response_time': 0,
                    'min_response_time': 0,
                    'requests_per_second': 0
                }
            
            # 计算总体统计
            total_requests = api_stats['Request Count'].sum()
            total_failures = api_stats['Failure Count'].sum()
            
            # 加权平均响应时间
            weighted_avg_response_time = (
                api_stats['Average Response Time'] * api_stats['Request Count']
            ).sum() / total_requests if total_requests > 0 else 0
            
            success_rate = ((total_requests - total_failures) / total_requests * 100) if total_requests > 0 else 0
            
            return {
                'total_requests': int(total_requests),
                'total_failures': int(total_failures),
                'success_rate': float(success_rate),
                'avg_response_time': float(weighted_avg_response_time),
                'max_response_time': float(api_stats['Max Response Time'].max()),
                'min_response_time': float(api_stats['Min Response Time'].min()),
                'requests_per_second': float(api_stats['Requests/s'].sum())
            }
            
        except Exception as e:
            logger.error(f"Error parsing Locust results: {e}")
            return None
    
    def find_max_users(self, pod_count: int, max_users: int = 200) -> Dict:
        """使用二分搜索找到最大并发用户数"""
        logger.info(f"\n{'='*60}")
        logger.info(f"Testing with {pod_count} pods")
        logger.info(f"{'='*60}")
        
        # 扩展到指定的Pod数量
        if not self.scale_deployment(pod_count):
            return {
                'pod_count': pod_count,
                'max_users': 0,
                'avg_response_time': 0,
                'success_rate': 0,
                'error': 'Failed to scale deployment'
            }
        
        # 获取Pod状态
        pod_status = self.get_pod_status()
        logger.info(f"Pod status: {pod_status}")
        
        # 二分搜索最大用户数
        low, high = 1, max_users
        max_successful_users = 0
        best_result = None
        
        while low <= high:
            mid = (low + high) // 2
            logger.info(f"Testing {mid} users...")
            
            # 运行测试
            result = self.run_locust_test(mid, spawn_rate=2, duration=120)
            
            if result and result['success_rate'] >= 99.0:  # 99%成功率阈值
                max_successful_users = mid
                best_result = result
                low = mid + 1
                logger.info(f"✓ {mid} users successful (success rate: {result['success_rate']:.1f}%, "
                          f"avg response time: {result['avg_response_time']:.2f}ms)")
            else:
                high = mid - 1
                if result:
                    logger.info(f"✗ {mid} users failed (success rate: {result['success_rate']:.1f}%, "
                              f"avg response time: {result['avg_response_time']:.2f}ms)")
                else:
                    logger.info(f"✗ {mid} users failed (test error)")
        
        # 确认测试 - 运行更长时间的测试来确认结果
        if max_successful_users > 0:
            logger.info(f"Confirming {max_successful_users} users with longer test...")
            final_result = self.run_locust_test(max_successful_users, spawn_rate=1, duration=300)
            if final_result and final_result['success_rate'] >= 99.0:
                best_result = final_result
                logger.info(f"✓ Confirmed {max_successful_users} users")
            else:
                # 如果确认测试失败，降低用户数
                max_successful_users = max(1, max_successful_users - 1)
                logger.warning(f"Confirmation failed, reducing to {max_successful_users} users")
        
        result_dict = {
            'pod_count': pod_count,
            'max_users': max_successful_users,
            'avg_response_time': best_result['avg_response_time'] if best_result else 0,
            'success_rate': best_result['success_rate'] if best_result else 0,
            'requests_per_second': best_result['requests_per_second'] if best_result else 0,
            'max_response_time': best_result['max_response_time'] if best_result else 0,
            'min_response_time': best_result['min_response_time'] if best_result else 0
        }
        
        logger.info(f"Final result for {pod_count} pods: {result_dict}")
        return result_dict
    
    def run_experiments(self, pod_counts: List[int], max_users: int = 200):
        """运行完整的实验套件"""
        logger.info("Starting CloudPose Load Testing Experiments")
        logger.info(f"Target host: {self.host_url}")
        logger.info(f"Pod counts to test: {pod_counts}")
        logger.info(f"Max users per test: {max_users}")
        logger.info("=" * 60)
        
        # 检查先决条件
        if not self.check_kubectl():
            logger.error("kubectl not available, aborting experiments")
            return
        
        if not self.check_deployment_exists():
            logger.error("Deployment not found, aborting experiments")
            return
        
        # 运行实验
        for pod_count in pod_counts:
            try:
                result = self.find_max_users(pod_count, max_users)
                self.results.append(result)
                
                logger.info(f"Completed test for {pod_count} pods: "
                          f"Max users: {result['max_users']}, "
                          f"Avg response time: {result['avg_response_time']:.2f}ms")
                
                # 在测试之间稍作休息
                time.sleep(30)
                
            except Exception as e:
                logger.error(f"Error in experiment for {pod_count} pods: {e}")
                self.results.append({
                    'pod_count': pod_count,
                    'max_users': 0,
                    'avg_response_time': 0,
                    'success_rate': 0,
                    'error': str(e)
                })
        
        # 保存和展示结果
        self.save_results()
        self.generate_report()
        self.generate_plots()
    
    def save_results(self):
        """保存实验结果"""
        # JSON格式
        json_file = f'experiment_results_{self.experiment_id}.json'
        with open(json_file, 'w') as f:
            json.dump({
                'experiment_id': self.experiment_id,
                'host_url': self.host_url,
                'timestamp': datetime.now().isoformat(),
                'results': self.results
            }, f, indent=2)
        
        # CSV格式
        csv_file = f'experiment_results_{self.experiment_id}.csv'
        with open(csv_file, 'w', newline='') as f:
            if self.results:
                fieldnames = self.results[0].keys()
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(self.results)
        
        logger.info(f"Results saved to {json_file} and {csv_file}")
    
    def generate_report(self):
        """生成实验报告"""
        print("\n" + "=" * 80)
        print("CLOUDPOSE LOAD TESTING EXPERIMENT RESULTS")
        print("=" * 80)
        print(f"Experiment ID: {self.experiment_id}")
        print(f"Target Host: {self.host_url}")
        print(f"Timestamp: {datetime.now()}")
        print("-" * 80)
        
        if not self.results:
            print("No results to display")
            return
        
        # 表格标题
        print(f"{'Pods':<6} {'Max Users':<12} {'Avg RT (ms)':<12} {'Max RT (ms)':<12} "
              f"{'Success Rate (%)':<16} {'RPS':<8}")
        print("-" * 80)
        
        # 结果行
        for result in self.results:
            error_msg = result.get('error', '')
            if error_msg:
                print(f"{result['pod_count']:<6} {'ERROR':<12} {'-':<12} {'-':<12} "
                      f"{'-':<16} {'-':<8} ({error_msg})")
            else:
                print(f"{result['pod_count']:<6} {result['max_users']:<12} "
                      f"{result['avg_response_time']:<12.2f} {result.get('max_response_time', 0):<12.2f} "
                      f"{result['success_rate']:<16.1f} {result.get('requests_per_second', 0):<8.1f}")
        
        print("-" * 80)
    
    def generate_plots(self):
        """生成性能图表"""
        if not self.results:
            return
        
        # 过滤出有效结果
        valid_results = [r for r in self.results if 'error' not in r and r['max_users'] > 0]
        
        if not valid_results:
            logger.warning("No valid results for plotting")
            return
        
        # 创建图表
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        
        pods = [r['pod_count'] for r in valid_results]
        max_users = [r['max_users'] for r in valid_results]
        avg_response_times = [r['avg_response_time'] for r in valid_results]
        rps = [r.get('requests_per_second', 0) for r in valid_results]
        
        # 1. 最大用户数 vs Pod数量
        ax1.plot(pods, max_users, 'bo-', linewidth=2, markersize=8)
        ax1.set_xlabel('Number of Pods')
        ax1.set_ylabel('Maximum Concurrent Users')
        ax1.set_title('Scalability: Max Users vs Pod Count')
        ax1.grid(True, alpha=0.3)
        
        # 2. 平均响应时间 vs Pod数量
        ax2.plot(pods, avg_response_times, 'ro-', linewidth=2, markersize=8)
        ax2.set_xlabel('Number of Pods')
        ax2.set_ylabel('Average Response Time (ms)')
        ax2.set_title('Performance: Response Time vs Pod Count')
        ax2.grid(True, alpha=0.3)
        
        # 3. 请求处理率 vs Pod数量
        ax3.plot(pods, rps, 'go-', linewidth=2, markersize=8)
        ax3.set_xlabel('Number of Pods')
        ax3.set_ylabel('Requests Per Second')
        ax3.set_title('Throughput: RPS vs Pod Count')
        ax3.grid(True, alpha=0.3)
        
        # 4. 效率指标（用户数/Pod）
        efficiency = [users/pod for users, pod in zip(max_users, pods)]
        ax4.bar(pods, efficiency, alpha=0.7, color='purple')
        ax4.set_xlabel('Number of Pods')
        ax4.set_ylabel('Users per Pod')
        ax4.set_title('Efficiency: Users per Pod')
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        # 保存图表
        plot_file = f'experiment_plots_{self.experiment_id}.png'
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        logger.info(f"Plots saved to {plot_file}")
        
        # 显示图表（如果在支持的环境中）
        try:
            plt.show()
        except:
            logger.info("Cannot display plots in this environment")

def main():
    parser = argparse.ArgumentParser(description='CloudPose Load Testing Automation')
    parser.add_argument('--host', required=True, help='Target host URL (e.g., http://your-k8s-ip:30000)')
    parser.add_argument('--pods', default='1,2,4', help='Comma-separated list of pod counts to test')
    parser.add_argument('--max-users', type=int, default=200, help='Maximum users to test')
    parser.add_argument('--deployment', default='cloudpose-deployment', help='Kubernetes deployment name')
    
    args = parser.parse_args()
    
    # 解析Pod数量列表
    pod_counts = [int(x.strip()) for x in args.pods.split(',')]
    
    # 创建实验运行器
    runner = ExperimentRunner(args.host, args.deployment)
    
    # 运行实验
    try:
        runner.run_experiments(pod_counts, args.max_users)
    except KeyboardInterrupt:
        logger.info("Experiment interrupted by user")
        runner.save_results()
        runner.generate_report()
    except Exception as e:
        logger.error(f"Experiment failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
