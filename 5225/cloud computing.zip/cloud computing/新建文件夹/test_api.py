#!/usr/bin/env python3
"""
CloudPose API测试脚本
用于验证部署的CloudPose服务是否正常工作
"""

import requests
import base64
import json
import uuid
import time
import argparse
from PIL import Image
from io import BytesIO
import sys

def create_test_image():
    """创建一个测试图像"""
    # 创建一个简单的测试图像
    img = Image.new('RGB', (640, 480), color='lightblue')
    
    # 添加一些图形来模拟人体
    from PIL import ImageDraw
    draw = ImageDraw.Draw(img)
    
    # 绘制简单的人形
    # 头部
    draw.ellipse([300, 50, 340, 90], fill='red', outline='black', width=2)
    # 身体
    draw.rectangle([310, 90, 330, 200], fill='blue', outline='black', width=2)
    # 左臂
    draw.rectangle([280, 100, 310, 120], fill='green', outline='black', width=2)
    # 右臂  
    draw.rectangle([330, 100, 360, 120], fill='green', outline='black', width=2)
    # 左腿
    draw.rectangle([305, 200, 320, 300], fill='purple', outline='black', width=2)
    # 右腿
    draw.rectangle([320, 200, 335, 300], fill='purple', outline='black', width=2)
    
    # 添加标题
    draw.text((200, 20), "CloudPose Test Image", fill='black')
    
    return img

def image_to_base64(image):
    """将PIL图像转换为base64字符串"""
    buffer = BytesIO()
    image.save(buffer, format='JPEG', quality=90)
    image_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return image_data

def test_health_endpoint(base_url):
    """测试健康检查端点"""
    print("\n🔍 Testing health endpoint...")
    
    try:
        response = requests.get(f"{base_url}/health", timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Health check passed: {result}")
            return True
        else:
            print(f"❌ Health check failed: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Health check error: {e}")
        return False

def test_root_endpoint(base_url):
    """测试根端点"""
    print("\n🔍 Testing root endpoint...")
    
    try:
        response = requests.get(base_url, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Root endpoint passed: {result.get('message', 'No message')}")
            return True
        else:
            print(f"❌ Root endpoint failed: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Root endpoint error: {e}")
        return False

def test_pose_detection_json(base_url, image_base64):
    """测试姿态检测JSON API"""
    print("\n🔍 Testing pose detection JSON API...")
    
    test_id = str(uuid.uuid4())
    payload = {
        "id": test_id,
        "image": image_base64
    }
    
    headers = {'Content-Type': 'application/json'}
    
    try:
        start_time = time.time()
        response = requests.post(
            f"{base_url}/api/pose_detection",
            json=payload,
            headers=headers,
            timeout=30
        )
        response_time = (time.time() - start_time) * 1000
        
        if response.status_code == 200:
            result = response.json()
            
            # 验证响应格式
            required_fields = ["id", "count", "boxes", "keypoints", 
                             "speed_preprocess", "speed_inference", "speed_postprocess"]
            
            missing_fields = [f for f in required_fields if f not in result]
            if missing_fields:
                print(f"❌ Missing fields: {missing_fields}")
                return False
            
            if result["id"] != test_id:
                print(f"❌ ID mismatch: expected {test_id}, got {result['id']}")
                return False
            
            print(f"✅ JSON API test passed!")
            print(f"   Response time: {response_time:.2f}ms")
            print(f"   Detected persons: {result['count']}")
            print(f"   Preprocessing: {result['speed_preprocess']:.2f}ms")
            print(f"   Inference: {result['speed_inference']:.2f}ms") 
            print(f"   Postprocessing: {result['speed_postprocess']:.2f}ms")
            print(f"   Total keypoints: {len(result['keypoints'][0]) if result['keypoints'] else 0}")
            
            return True
            
        else:
            print(f"❌ JSON API failed: HTTP {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ JSON API error: {e}")
        return False

def test_pose_detection_image(base_url, image_base64):
    """测试姿态检测图像API"""
    print("\n🔍 Testing pose detection image API...")
    
    test_id = str(uuid.uuid4())
    payload = {
        "id": test_id,
        "image": image_base64
    }
    
    headers = {'Content-Type': 'application/json'}
    
    try:
        start_time = time.time()
        response = requests.post(
            f"{base_url}/api/pose_detection_annotation",
            json=payload,
            headers=headers,
            timeout=30
        )
        response_time = (time.time() - start_time) * 1000
        
        if response.status_code == 200:
            result = response.json()
            
            if "id" not in result or "image" not in result:
                print("❌ Missing required fields in response")
                return False
            
            if result["id"] != test_id:
                print(f"❌ ID mismatch: expected {test_id}, got {result['id']}")
                return False
            
            # 验证返回的图像是有效的base64
            try:
                decoded_image = base64.b64decode(result["image"])
                print(f"✅ Image API test passed!")
                print(f"   Response time: {response_time:.2f}ms")
                print(f"   Annotated image size: {len(decoded_image)} bytes")
                
                # 可选：保存注释图像
                with open(f"annotated_test_{int(time.time())}.jpg", "wb") as f:
                    f.write(decoded_image)
                    print(f"   Annotated image saved")
                
                return True
                
            except Exception as e:
                print(f"❌ Invalid base64 image: {e}")
                return False
            
        else:
            print(f"❌ Image API failed: HTTP {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Image API error: {e}")
        return False

def test_stats_endpoint(base_url):
    """测试统计端点"""
    print("\n🔍 Testing stats endpoint...")
    
    try:
        response = requests.get(f"{base_url}/api/stats", timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Stats endpoint passed:")
            print(f"   Model loaded: {result.get('model_loaded', False)}")
            print(f"   Available endpoints: {result.get('available_endpoints', [])}")
            print(f"   Max workers: {result.get('max_workers', 'Unknown')}")
            return True
        else:
            print(f"❌ Stats endpoint failed: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Stats endpoint error: {e}")
        return False

def run_load_test(base_url, image_base64, requests_count=10):
    """运行简单的负载测试"""
    print(f"\n🔍 Running load test ({requests_count} requests)...")
    
    success_count = 0
    total_time = 0
    response_times = []
    
    for i in range(requests_count):
        test_id = str(uuid.uuid4())
        payload = {
            "id": test_id,
            "image": image_base64
        }
        
        try:
            start_time = time.time()
            response = requests.post(
                f"{base_url}/api/pose_detection",
                json=payload,
                headers={'Content-Type': 'application/json'},
                timeout=30
            )
            response_time = (time.time() - start_time) * 1000
            response_times.append(response_time)
            total_time += response_time
            
            if response.status_code == 200:
                success_count += 1
                print(f"   Request {i+1}/{requests_count}: ✅ ({response_time:.2f}ms)")
            else:
                print(f"   Request {i+1}/{requests_count}: ❌ HTTP {response.status_code}")
                
        except Exception as e:
            print(f"   Request {i+1}/{requests_count}: ❌ Error: {e}")
    
    success_rate = (success_count / requests_count) * 100
    avg_response_time = total_time / requests_count if requests_count > 0 else 0
    min_response_time = min(response_times) if response_times else 0
    max_response_time = max(response_times) if response_times else 0
    
    print(f"\n📊 Load test results:")
    print(f"   Total requests: {requests_count}")
    print(f"   Successful requests: {success_count}")
    print(f"   Success rate: {success_rate:.1f}%")
    print(f"   Average response time: {avg_response_time:.2f}ms")
    print(f"   Min response time: {min_response_time:.2f}ms")
    print(f"   Max response time: {max_response_time:.2f}ms")
    
    return success_rate >= 90  # 90%成功率阈值

def main():
    parser = argparse.ArgumentParser(description='Test CloudPose API endpoints')
    parser.add_argument('--host', required=True, 
                       help='CloudPose service URL (e.g., http://47.xxx.xxx.xxx:30000)')
    parser.add_argument('--load-test', type=int, default=0,
                       help='Number of requests for load test (0 to skip)')
    parser.add_argument('--image', help='Path to test image file (optional)')
    
    args = parser.parse_args()
    
    base_url = args.host.rstrip('/')
    
    print(f"🚀 Testing CloudPose API at: {base_url}")
    print("=" * 60)
    
    # 准备测试图像
    if args.image:
        try:
            with Image.open(args.image) as img:
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                test_image = img.copy()
            print(f"📷 Using provided image: {args.image}")
        except Exception as e:
            print(f"❌ Failed to load image {args.image}: {e}")
            print("📷 Creating synthetic test image...")
            test_image = create_test_image()
    else:
        print("📷 Creating synthetic test image...")
        test_image = create_test_image()
    
    # 转换为base64
    image_base64 = image_to_base64(test_image)
    print(f"📷 Test image size: {len(image_base64)} characters (base64)")
    
    # 运行测试
    tests = [
        ("Health Check", lambda: test_health_endpoint(base_url)),
        ("Root Endpoint", lambda: test_root_endpoint(base_url)),
        ("Stats Endpoint", lambda: test_stats_endpoint(base_url)),
        ("JSON API", lambda: test_pose_detection_json(base_url, image_base64)),
        ("Image API", lambda: test_pose_detection_image(base_url, image_base64)),
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # 可选的负载测试
    if args.load_test > 0:
        load_result = run_load_test(base_url, image_base64, args.load_test)
        results.append(("Load Test", load_result))
    
    # 总结结果
    print("\n" + "=" * 60)
    print("📋 TEST SUMMARY")
    print("=" * 60)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name:<20}: {status}")
        if result:
            passed += 1
    
    print("-" * 60)
    print(f"Overall: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")
    
    if passed == total:
        print("🎉 All tests passed! CloudPose API is working correctly.")
        sys.exit(0)
    else:
        print("⚠️  Some tests failed. Please check the service configuration.")
        sys.exit(1)

if __name__ == "__main__":
    main()
