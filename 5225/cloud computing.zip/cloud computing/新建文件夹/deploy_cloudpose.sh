

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 配置变量
APP_NAME="cloudpose"
DEPLOYMENT_NAME="cloudpose-deployment"
SERVICE_NAME="cloudpose-service"
DOCKER_IMAGE="cloudpose:latest"
NAMESPACE="default"

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_step "Checking dependencies..."
    
    # 检查kubectl
    if ! command -v kubectl >/dev/null 2>&1; then
        log_error "kubectl is not installed"
        exit 1
    fi
    
    # 检查docker
    if ! command -v docker >/dev/null 2>&1; then
        log_error "docker is not installed"
        exit 1
    fi
    
    # 检查集群连接
    if ! kubectl cluster-info >/dev/null 2>&1; then
        log_error "Cannot connect to Kubernetes cluster"
        exit 1
    fi
    
    log_info "All dependencies satisfied"
}

# 检查必要文件
check_files() {
    log_step "Checking required files..."
    
    local files=("app.py" "requirements.txt" "Dockerfile" "deployment.yaml" "movenet-full-256.tflite")
    
    for file in "${files[@]}"; do
        if [[ ! -f "$file" ]]; then
            log_error "Required file $file not found"
            exit 1
        fi
    done
    
    log_info "All required files found"
}

# 构建Docker镜像
build_image() {
    log_step "Building Docker image..."
    
    # 检查模型文件大小
    local model_size=$(stat -c%s "movenet-full-256.tflite" 2>/dev/null || echo "0")
    if [[ $model_size -lt 1000000 ]]; then  # 小于1MB可能有问题
        log_warn "Model file seems too small (${model_size} bytes). Please verify."
    fi
    
    # 构建镜像
    log_info "Building Docker image: $DOCKER_IMAGE"
    docker build -t $DOCKER_IMAGE . 
    
    # 验证镜像
    if docker images | grep -q "cloudpose.*latest"; then
        log_info "Docker image built successfully"
    else
        log_error "Failed to build Docker image"
        exit 1
    fi
    
    # 显示镜像信息
    log_info "Image details:"
    docker images | grep cloudpose
}

# 推送镜像到所有节点
distribute_image() {
    log_step "Distributing image to all nodes..."
    
    # 获取所有节点
    local nodes=$(kubectl get nodes -o jsonpath='{.items[*].metadata.name}')
    local current_node=$(hostname)
    
    log_info "Current node: $current_node"
    log_info "All nodes: $nodes"
    
    # 保存镜像
    log_info "Saving Docker image to tar file..."
    docker save $DOCKER_IMAGE | gzip > ${APP_NAME}_image.tar.gz
    
    # 分发到其他节点
    for node in $nodes; do
        if [[ "$node" != "$current_node" ]]; then
            log_info "Distributing image to node: $node"
            
            # 尝试通过SSH复制镜像
            if scp ${APP_NAME}_image.tar.gz $node:/tmp/ 2>/dev/null; then
                ssh $node "docker load < /tmp/${APP_NAME}_image.tar.gz && rm /tmp/${APP_NAME}_image.tar.gz" 2>/dev/null || log_warn "Failed to load image on $node"
            else
                log_warn "Cannot access node $node via SSH. Manual image distribution may be required."
            fi
        fi
    done
    
    # 清理本地tar文件
    rm -f ${APP_NAME}_image.tar.gz
    
    log_info "Image distribution completed"
}

# 部署应用
deploy_app() {
    log_step "Deploying CloudPose application..."
    
    # 删除现有部署（如果存在）
    if kubectl get deployment $DEPLOYMENT_NAME >/dev/null 2>&1; then
        log_info "Removing existing deployment..."
        kubectl delete deployment $DEPLOYMENT_NAME --ignore-not-found=true
        
        # 等待Pod终止
        log_info "Waiting for pods to terminate..."
        kubectl wait --for=delete pods -l app=$APP_NAME --timeout=60s || true
    fi
    
    # 删除现有服务（如果存在）
    if kubectl get service $SERVICE_NAME >/dev/null 2>&1; then
        log_info "Removing existing service..."
        kubectl delete service $SERVICE_NAME --ignore-not-found=true
    fi
    
    # 应用新的配置
    log_info "Applying Kubernetes configurations..."
    kubectl apply -f deployment.yaml
    
    # 等待部署就绪
    log_info "Waiting for deployment to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/$DEPLOYMENT_NAME
    
    log_info "Application deployed successfully"
}

# 验证部署
verify_deployment() {
    log_step "Verifying deployment..."
    
    # 检查部署状态
    echo "Deployment status:"
    kubectl get deployment $DEPLOYMENT_NAME -o wide
    
    echo -e "\nPod status:"
    kubectl get pods -l app=$APP_NAME -o wide
    
    echo -e "\nService status:"
    kubectl get service $SERVICE_NAME -o wide
    
    # 检查Pod日志
    echo -e "\nRecent pod logs:"
    local pod_name=$(kubectl get pods -l app=$APP_NAME -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [[ -n "$pod_name" ]]; then
        kubectl logs $pod_name --tail=10 || log_warn "Could not retrieve pod logs"
    fi
    
    # 测试服务可达性
    echo -e "\nTesting service connectivity..."
    local service_ip=$(kubectl get service $SERVICE_NAME -o jsonpath='{.spec.clusterIP}')
    local node_port=$(kubectl get service $SERVICE_NAME -o jsonpath='{.spec.ports[0].nodePort}')
    
    if [[ -n "$service_ip" ]]; then
        log_info "Service ClusterIP: $service_ip:60000"
    fi
    
    if [[ -n "$node_port" ]]; then
        log_info "Service NodePort: $node_port"
        
        # 获取节点外部IP
        local external_ip=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}' 2>/dev/null || echo "")
        if [[ -n "$external_ip" ]]; then
            log_info "External access: http://$external_ip:$node_port"
        else
            log_warn "No external IP found. Check your cloud provider configuration."
        fi
    fi
}

# 健康检查
health_check() {
    log_step "Performing health check..."
    
    local pod_name=$(kubectl get pods -l app=$APP_NAME -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    
    if [[ -n "$pod_name" ]]; then
        log_info "Testing health endpoint..."
        
        # 在Pod内部测试健康检查
        if kubectl exec $pod_name -- curl -s http://localhost:60000/health >/dev/null 2>&1; then
            log_info "Health check passed"
        else
            log_warn "Health check failed"
        fi
        
        # 测试根端点
        local response=$(kubectl exec $pod_name -- curl -s http://localhost:60000/ 2>/dev/null || echo "")
        if [[ "$response" == *"CloudPose API is running"* ]]; then
            log_info "API endpoint responding correctly"
        else
            log_warn "API endpoint not responding as expected"
        fi
    else
        log_error "No running pods found"
        return 1
    fi
}

# 扩展部署
scale_deployment() {
    local replicas=${1:-1}
    
    log_step "Scaling deployment to $replicas replicas..."
    
    kubectl scale deployment $DEPLOYMENT_NAME --replicas=$replicas
    
    log_info "Waiting for scaling to complete..."
    kubectl wait --for=condition=available --timeout=300s deployment/$DEPLOYMENT_NAME
    
    echo "Deployment scaled successfully:"
    kubectl get deployment $DEPLOYMENT_NAME
}

# 查看日志
show_logs() {
    local follow=${1:-false}
    
    log_step "Showing application logs..."
    
    if [[ "$follow" == "true" ]]; then
        kubectl logs -l app=$APP_NAME -f --tail=50
    else
        kubectl logs -l app=$APP_NAME --tail=50
    fi
}

# 清理部署
cleanup() {
    log_step "Cleaning up CloudPose deployment..."
    
    log_info "Removing deployment..."
    kubectl delete deployment $DEPLOYMENT_NAME --ignore-not-found=true
    
    log_info "Removing service..."
    kubectl delete service $SERVICE_NAME --ignore-not-found=true
    
    log_info "Cleanup completed"
}

# 显示使用说明
show_usage() {
    echo "CloudPose Deployment Script"
    echo ""
    echo "Usage: $0 [COMMAND] [OPTIONS]"
    echo ""
    echo "Commands:"
    echo "  deploy     - Build image and deploy application (default)"
    echo "  build      - Build Docker image only"
    echo "  apply      - Apply Kubernetes configurations only"
    echo "  verify     - Verify deployment status"
    echo "  health     - Perform health check"
    echo "  scale N    - Scale deployment to N replicas"
    echo "  logs       - Show application logs"
    echo "  logs -f    - Follow application logs"
    echo "  cleanup    - Remove deployment and service"
    echo "  help       - Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 deploy          # Full deployment"
    echo "  $0 scale 3         # Scale to 3 replicas"
    echo "  $0 logs -f         # Follow logs"
    echo "  $0 cleanup         # Remove everything"
}

# 主函数
main() {
    local command=${1:-deploy}
    
    case $command in
        "deploy")
            check_dependencies
            check_files
            build_image
            distribute_image
            deploy_app
            verify_deployment
            health_check
            log_info "CloudPose deployment completed successfully!"
            ;;
        "build")
            check_dependencies
            check_files
            build_image
            ;;
        "apply")
            check_dependencies
            deploy_app
            verify_deployment
            ;;
        "verify")
            check_dependencies
            verify_deployment
            ;;
        "health")
            check_dependencies
            health_check
            ;;
        "scale")
            if [[ -z "$2" ]]; then
                log_error "Please specify number of replicas"
                exit 1
            fi
            check_dependencies
            scale_deployment $2
            ;;
        "logs")
            check_dependencies
            if [[ "$2" == "-f" ]]; then
                show_logs true
            else
                show_logs false
            fi
            ;;
        "cleanup")
            check_dependencies
            cleanup
            ;;
        "help"|"-h"|"--help")
            show_usage
            ;;
        *)
            log_error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"