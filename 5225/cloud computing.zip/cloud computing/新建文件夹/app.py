from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import base64
import cv2
import numpy as np
import tensorflow as tf
import uuid
import time
import threading
import logging
from typing import List, Dict
import os
import tempfile
import asyncio
from concurrent.futures import ThreadPoolExecutor

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="CloudPose API", version="1.0.0", description="Pose Detection Web Service")

# 请求模型
class ImageRequest(BaseModel):
    id: str
    image: str  # base64编码的图像

class KeyPoint(BaseModel):
    x: float
    y: float
    p: float

class BoundingBox(BaseModel):
    x: float
    y: float
    width: float
    height: float
    probability: float

class PoseResponse(BaseModel):
    id: str
    count: int
    boxes: List[BoundingBox]
    keypoints: List[List[List[float]]]
    speed_preprocess: float
    speed_inference: float
    speed_postprocess: float

class ImageResponse(BaseModel):
    id: str
    image: str  # base64编码的注释图像

# 全局变量
interpreter = None
executor = ThreadPoolExecutor(max_workers=4)

def load_model():
    """加载TensorFlow Lite模型"""
    global interpreter
    try:
        model_path = 'movenet-full-256.tflite'
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found: {model_path}")
        
        interpreter = tf.lite.Interpreter(model_path=model_path)
        interpreter.allocate_tensors()
        logger.info("Model loaded successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to load model: {e}")
        return False

def decode_base64_image(base64_string: str) -> np.ndarray:
    """解码base64图像"""
    try:
        # 移除可能的数据URL前缀
        if base64_string.startswith('data:image'):
            base64_string = base64_string.split(',')[1]
        
        image_data = base64.b64decode(base64_string)
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Unable to decode image")
        
        return img
    except Exception as e:
        logger.error(f"Error decoding base64 image: {e}")
        raise HTTPException(status_code=400, detail=f"Invalid base64 image: {str(e)}")

def encode_image_to_base64(image: np.ndarray) -> str:
    """编码图像为base64"""
    try:
        _, buffer = cv2.imencode('.jpg', image)
        image_base64 = base64.b64encode(buffer).decode('utf-8')
        return image_base64
    except Exception as e:
        logger.error(f"Error encoding image to base64: {e}")
        raise HTTPException(status_code=500, detail="Error encoding image")

def detect_pose(img: np.ndarray) -> tuple:
    """姿态检测核心函数"""
    global interpreter
    
    if interpreter is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    start_preprocess = time.time()
    
    try:
        # 获取输入和输出详情
        input_details = interpreter.get_input_details()
        output_details = interpreter.get_output_details()
        
        # 调整图像大小和归一化
        img_height, img_width, _ = img.shape
        input_shape = input_details[0]['shape'][1:3]  # (height, width)
        resized_image = cv2.resize(img, (input_shape[1], input_shape[0]))  # cv2.resize expects (width, height)
        input_data = np.expand_dims(resized_image, axis=0).astype(np.float32) / 255.0
        
        preprocess_time = time.time() - start_preprocess
        
        # 推理
        start_inference = time.time()
        interpreter.set_tensor(input_details[0]['index'], input_data)
        interpreter.invoke()
        inference_time = time.time() - start_inference
        
        # 后处理
        start_postprocess = time.time()
        keypoints_output = interpreter.get_tensor(output_details[0]['index'])
        keypoints = keypoints_output[0]  # Shape: (17, 3) - 17关键点，(y, x, confidence)
        
        # 创建边界框
        boxes = []
        if len(keypoints) > 0:
            # 过滤有效关键点
            valid_points = keypoints[keypoints[:, 2] > 0.3]  # 置信度阈值
            if len(valid_points) > 0:
                # 计算边界框（基于有效关键点）
                min_x = np.min(valid_points[:, 1]) * img_width
                max_x = np.max(valid_points[:, 1]) * img_width
                min_y = np.min(valid_points[:, 0]) * img_height
                max_y = np.max(valid_points[:, 0]) * img_height
                
                # 添加一些边距
                margin = 0.1
                width = max_x - min_x
                height = max_y - min_y
                min_x = max(0, min_x - width * margin)
                min_y = max(0, min_y - height * margin)
                max_x = min(img_width, max_x + width * margin)
                max_y = min(img_height, max_y + height * margin)
                
                boxes.append(BoundingBox(
                    x=float(min_x),
                    y=float(min_y),
                    width=float(max_x - min_x),
                    height=float(max_y - min_y),
                    probability=float(np.mean(valid_points[:, 2]))
                ))
        
        postprocess_time = time.time() - start_postprocess
        
        return keypoints, boxes, preprocess_time * 1000, inference_time * 1000, postprocess_time * 1000
        
    except Exception as e:
        logger.error(f"Error in pose detection: {e}")
        raise HTTPException(status_code=500, detail=f"Pose detection failed: {str(e)}")

def annotate_image(img: np.ndarray, keypoints: np.ndarray) -> np.ndarray:
    """在图像上注释关键点"""
    annotated_image = img.copy()
    img_height, img_width, _ = img.shape
    
    # COCO格式的17个关键点连接
    connections = [
        (5, 6),   # 左肩-右肩
        (5, 7),   # 左肩-左肘
        (7, 9),   # 左肘-左腕
        (6, 8),   # 右肩-右肘
        (8, 10),  # 右肘-右腕
        (5, 11),  # 左肩-左髋
        (6, 12),  # 右肩-右髋
        (11, 12), # 左髋-右髋
        (11, 13), # 左髋-左膝
        (13, 15), # 左膝-左踝
        (12, 14), # 右髋-右膝
        (14, 16), # 右膝-右踝
        (0, 1),   # 鼻子-左眼
        (0, 2),   # 鼻子-右眼
        (1, 3),   # 左眼-左耳
        (2, 4),   # 右眼-右耳
    ]
    
    confidence_threshold = 0.3
    
    # 绘制关键点
    for i, kp in enumerate(keypoints):
        y, x, confidence = kp
        if confidence > confidence_threshold:
            x_coord = int(x * img_width)
            y_coord = int(y * img_height)
            # 使用不同颜色标记不同类型的关键点
            if i < 5:  # 面部关键点
                color = (255, 0, 0)  # 蓝色
            elif i < 11:  # 上半身关键点
                color = (0, 255, 0)  # 绿色
            else:  # 下半身关键点
                color = (0, 0, 255)  # 红色
            
            cv2.circle(annotated_image, (x_coord, y_coord), 5, color, -1)
            cv2.putText(annotated_image, str(i), (x_coord + 5, y_coord), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1)
    
    # 绘制连接线
    for start, end in connections:
        if start < len(keypoints) and end < len(keypoints):
            y1, x1, c1 = keypoints[start]
            y2, x2, c2 = keypoints[end]
            if c1 > confidence_threshold and c2 > confidence_threshold:
                x1_coord = int(x1 * img_width)
                y1_coord = int(y1 * img_height)
                x2_coord = int(x2 * img_width)
                y2_coord = int(y2 * img_height)
                cv2.line(annotated_image, (x1_coord, y1_coord), 
                        (x2_coord, y2_coord), (0, 255, 255), 2)  # 黄色连接线
    
    return annotated_image

@app.on_event("startup")
async def startup_event():
    """启动时加载模型"""
    success = load_model()
    if not success:
        logger.error("Failed to load model on startup")
        raise Exception("Model loading failed")

@app.on_event("shutdown")
async def shutdown_event():
    """关闭时清理资源"""
    executor.shutdown(wait=True)

@app.get("/")
async def root():
    """健康检查端点"""
    return {
        "message": "CloudPose API is running",
        "status": "healthy",
        "model_loaded": interpreter is not None
    }

@app.get("/health")
async def health_check():
    """Kubernetes健康检查"""
    if interpreter is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    return {"status": "healthy"}

def process_pose_detection(request: ImageRequest) -> PoseResponse:
    """处理姿态检测的同步函数"""
    try:
        # 解码图像
        img = decode_base64_image(request.image)
        
        # 姿态检测
        keypoints, boxes, preprocess_time, inference_time, postprocess_time = detect_pose(img)
        
        # 格式化关键点 - 转换为 [x, y, confidence] 格式
        formatted_keypoints = []
        if len(keypoints) > 0:
            kp_list = []
            for kp in keypoints:
                y, x, confidence = kp  # MoveNet输出格式: (y, x, confidence)
                kp_list.append([float(x), float(y), float(confidence)])  # 转换为 [x, y, confidence]
            formatted_keypoints.append(kp_list)
        
        response = PoseResponse(
            id=request.id,
            count=1 if len(keypoints) > 0 else 0,
            boxes=boxes,
            keypoints=formatted_keypoints,
            speed_preprocess=preprocess_time,
            speed_inference=inference_time,
            speed_postprocess=postprocess_time
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error in pose detection: {e}")
        raise HTTPException(status_code=500, detail=str(e))

def process_pose_annotation(request: ImageRequest) -> ImageResponse:
    """处理姿态注释的同步函数"""
    try:
        # 解码图像
        img = decode_base64_image(request.image)
        
        # 姿态检测
        keypoints, _, _, _, _ = detect_pose(img)
        
        # 注释图像
        annotated_img = annotate_image(img, keypoints)
        
        # 编码为base64
        annotated_base64 = encode_image_to_base64(annotated_img)
        
        response = ImageResponse(
            id=request.id,
            image=annotated_base64
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error in pose detection annotation: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/pose_detection", response_model=PoseResponse)
async def pose_detection_json(request: ImageRequest):
    """姿态检测JSON API - 返回关键点数据"""
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, process_pose_detection, request)
    return result

@app.post("/api/pose_detection_annotation", response_model=ImageResponse)
async def pose_detection_image(request: ImageRequest):
    """姿态检测图像API - 返回注释图像"""
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, process_pose_annotation, request)
    return result

@app.get("/api/stats")
async def get_stats():
    """获取API统计信息"""
    return {
        "model_loaded": interpreter is not None,
        "available_endpoints": [
            "/api/pose_detection",
            "/api/pose_detection_annotation"
        ],
        "supported_formats": ["jpg", "png"],
        "max_workers": executor._max_workers
    }

if __name__ == "__main__":
    import uvicorn
    
    # 检查模型文件
    if not os.path.exists('movenet-full-256.tflite'):
        logger.error("Model file 'movenet-full-256.tflite' not found!")
        exit(1)
    
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=60000,
        workers=1,  # 单进程，因为TensorFlow Lite在多进程间共享有问题
        access_log=True,
        log_level="info"
    )