#!/bin/bash
# setup_aliyun_environment.sh
# 阿里云环境自动配置脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "This script should not be run as root"
        exit 1
    fi
}

# 更新系统
update_system() {
    log_info "Updating system packages..."
    sudo apt-get update -y
    sudo apt-get upgrade -y
    sudo apt-get install -y curl wget git vim htop net-tools
}

# 安装Docker
install_docker() {
    log_info "Installing Docker..."
    
    # 卸载旧版本
    sudo apt-get remove -y docker docker-engine docker.io containerd runc || true
    
    # 安装依赖
    sudo apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # 添加Docker官方GPG密钥
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    
    # 设置stable仓库
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # 安装Docker Engine
    sudo apt-get update -y
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    # 将当前用户添加到docker组
    sudo usermod -aG docker $USER
    
    # 启动并启用Docker
    sudo systemctl start docker
    sudo systemctl enable docker
    
    log_info "Docker installed successfully"
}

# 安装Kubernetes
install_kubernetes() {
    log_info "Installing Kubernetes..."
    
    # 关闭swap
    sudo swapoff -a
    sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
    
    # 加载必要的内核模块
    cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF
    
    sudo modprobe overlay
    sudo modprobe br_netfilter
    
    # 设置内核参数
    cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF
    
    sudo sysctl --system
    
    # 安装kubeadm, kubelet, kubectl
    sudo apt-get update -y
    sudo apt-get install -y apt-transport-https ca-certificates curl
    
    curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
    
    cat <<EOF | sudo tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF
    
    sudo apt-get update -y
    sudo apt-get install -y kubelet=1.28.2-00 kubeadm=1.28.2-00 kubectl=1.28.2-00
    sudo apt-mark hold kubelet kubeadm kubectl
    
    # 启用kubelet
    sudo systemctl enable kubelet
    
    log_info "Kubernetes installed successfully"
}

# 配置containerd
configure_containerd() {
    log_info "Configuring containerd..."
    
    sudo mkdir -p /etc/containerd
    containerd config default | sudo tee /etc/containerd/config.toml
    
    # 配置systemd cgroup驱动
    sudo sed -i 's/SystemdCgroup \= false/SystemdCgroup \= true/g' /etc/containerd/config.toml
    
    sudo systemctl restart containerd
    sudo systemctl enable containerd
    
    log_info "containerd configured successfully"
}

# 初始化Kubernetes Master节点
init_k8s_master() {
    log_info "Initializing Kubernetes master node..."
    
    local pod_cidr="10.244.0.0/16"
    local api_server_ip=$(hostname -I | awk '{print $1}')
    
    log_info "Using API server IP: $api_server_ip"
    log_info "Using Pod CIDR: $pod_cidr"
    
    sudo kubeadm init \
        --pod-network-cidr=$pod_cidr \
        --apiserver-advertise-address=$api_server_ip \
        --control-plane-endpoint=$api_server_ip \
        --upload-certs
    
    # 配置kubectl
    mkdir -p $HOME/.kube
    sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
    sudo chown $(id -u):$(id -g) $HOME/.kube/config
    
    log_info "Kubernetes master initialized successfully"
    log_info "To join worker nodes, use the command printed above"
}

# 安装网络插件
install_network_plugin() {
    log_info "Installing Flannel network plugin..."
    
    kubectl apply -f https://github.com/flannel-io/flannel/releases/latest/download/kube-flannel.yml
    
    log_info "Waiting for network plugin to be ready..."
    sleep 30
    
    log_info "Flannel network plugin installed successfully"
}

# 加入Worker节点
join_worker() {
    log_info "This function should be run on worker nodes"
    log_info "Please run the kubeadm join command provided by the master node"
}

# 验证集群状态
verify_cluster() {
    log_info "Verifying cluster status..."
    
    echo "Nodes:"
    kubectl get nodes -o wide
    
    echo -e "\nPods in all namespaces:"
    kubectl get pods -A
    
    echo -e "\nCluster info:"
    kubectl cluster-info
}

# 安装必要的工具
install_tools() {
    log_info "Installing additional tools..."
    
    # 安装pip和Python包
    sudo apt-get install -y python3-pip
    pip3 install --user locust matplotlib pandas
    
    # 安装jq for JSON processing
    sudo apt-get install -y jq
    
    log_info "Additional tools installed successfully"
}

# 配置防火墙
configure_firewall() {
    log_info "Configuring firewall..."
    
    # 检查是否安装了ufw
    if command -v ufw >/dev/null 2>&1; then
        # Master节点端口
        sudo ufw allow 22/tcp     # SSH
        sudo ufw allow 6443/tcp   # Kubernetes API
        sudo ufw allow 2379:2380/tcp  # etcd
        sudo ufw allow 10250/tcp  # kubelet
        sudo ufw allow 10251/tcp  # kube-scheduler
        sudo ufw allow 10252/tcp  # kube-controller-manager
        sudo ufw allow 30000:32767/tcp  # NodePort range
        
        log_info "Firewall configured for Kubernetes master"
    else
        log_warn "ufw not found, skipping firewall configuration"
    fi
}

# 主函数
main() {
    log_info "Starting CloudPose environment setup on Alibaba Cloud..."
    
    check_root
    
    case "${1:-all}" in
        "docker")
            update_system
            install_docker
            log_info "Docker installation completed. Please logout and login again."
            ;;
        "k8s")
            install_kubernetes
            configure_containerd
            ;;
        "master")
            configure_firewall
            init_k8s_master
            install_network_plugin
            verify_cluster
            ;;
        "worker")
            configure_firewall
            join_worker
            ;;
        "tools")
            install_tools
            ;;
        "all")
            update_system
            install_docker
            install_kubernetes
            configure_containerd
            install_tools
            log_info "Base installation completed."
            log_info "Run './setup_aliyun_environment.sh master' to initialize master node"
            log_info "Run './setup_aliyun_environment.sh worker' on worker nodes"
            ;;
        *)
            echo "Usage: $0 {all|docker|k8s|master|worker|tools}"
            echo "  all    - Install Docker, Kubernetes, and tools"
            echo "  docker - Install Docker only"
            echo "  k8s    - Install Kubernetes only"
            echo "  master - Initialize Kubernetes master"
            echo "  worker - Join as worker node"
            echo "  tools  - Install additional tools"
            exit 1
            ;;
    esac
    
    log_info "Setup completed successfully!"
}

# 运行主函数
main "$@"